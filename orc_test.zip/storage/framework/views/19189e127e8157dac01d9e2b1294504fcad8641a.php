<h2>Upload Image</h2>
<form class="" enctype="multipart/form-data" method="post">
    <?php echo e(csrf_field()); ?>

    <input type="file" name="image" placeholder="select image">
    <button type="submit">Parse Text</button>
</form><?php /**PATH C:\Users\LENOVO\Desktop\Laravel\orc_test\resources\views/lara_ocr/upload_image.blade.php ENDPATH**/ ?>