<?php $__env->startSection('content'); ?>
    <h2>Output</h2>
    <?php if(!empty($parsedText)): ?>
        <p style="text-align: left;"><?php echo e($parsedText); ?></p>
    <?php else: ?>
        <p style="text-align: left; color: grey;">NO TEXT FOUND</p>
    <?php endif; ?>
    <a href="/">Parse another image</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('lara_ocr.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Desktop\Laravel\orc_test\resources\views/lara_ocr/parsed_text.blade.php ENDPATH**/ ?>